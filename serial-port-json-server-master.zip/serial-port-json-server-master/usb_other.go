// +build !linux

package main

func getUsbList() []UsbItem {
	return nil
}
